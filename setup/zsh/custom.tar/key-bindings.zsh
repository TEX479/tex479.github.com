# This file contains custom key-binds that are not defined in the default OMZ-installation

# [Ctrl + Backspace] - delete entire word backwards
bindkey -M emacs '^H' backward-kill-word
bindkey -M viins '^H' backward-kill-word
bindkey -M vicmd '^H' backward-kill-word

