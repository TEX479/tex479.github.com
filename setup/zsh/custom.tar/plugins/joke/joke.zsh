#!/usr/bin/zsh

echo "$(curl -fsSl 'https://v2.jokeapi.dev/joke/Any?safe-mode&format=txt')"

