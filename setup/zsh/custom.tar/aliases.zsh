
# "la", the way I'm used to
alias la="ls -AFh"

# crazy thingy from youtube vid https://www.youtube.com/watch?v=IYZDIhfAUM0
alias fman="compgen -c | fzf | xargs man"

# simple joke-alias I made as a proof-of-comcept
# after a little testing, I belive that zsh executes the echo-command to cache the output of curl,
# because it takes a few seconds longer to load the shell and joke always returns the same joke
# when executed in the same shell.
# DO NOT UNCOMMMENT THE NEXT LINE IF NO FURTHER RESEARCH WAS DONE OR THE ALIAS WAS MADE MORE EFFICIENT
#alias joke="echo \"$(curl -fsSl 'https://v2.jokeapi.dev/joke/Any?safe-mode&format=txt')\""
# The workaround for the delay and zsh's caching is to just make the command it's own file to be executed:
alias joke="$ZSH_CUSTOM/plugins/joke/joke.zsh"

# ...
alias atlauncher="sh -c 'cd /home/tex/Games/Minecraft/ATLauncher/ ; ./run.sh'"
