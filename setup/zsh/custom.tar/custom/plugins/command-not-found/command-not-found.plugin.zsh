# copied from /etc/bash.bashrc and modified
# to get the "Command 'X' not found, but can be installed with:" message
# To work with zsh, the name of the handler function was changed from
# "command_not_found_handle"  (provided in bash)
# to
# "command_not_found_handler" (provided in zsh)
# And that's it. Nothing more to get this script/feature to work.

# if the command-not-found package is installed, use it
if [ -x /usr/lib/command-not-found -o -x /usr/share/command-not-found/command-not-found ]; then
	function command_not_found_handler {
	        # check because c-n-f could've been removed in the meantime
                if [ -x /usr/lib/command-not-found ]; then
		   /usr/lib/command-not-found -- "$1"
                   return $?
                elif [ -x /usr/share/command-not-found/command-not-found ]; then
		   /usr/share/command-not-found/command-not-found -- "$1"
                   return $?
		else
		   printf "%s: command not found\n" "$1" >&2
		   return 127
		fi
	}
fi
