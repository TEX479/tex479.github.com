#!/usr/bin/zsh


# Function to find and run the correct "bin/activate" file for pythons virtual enviroments
activate() {
  # Search for directories containing "bin/activate"
  found_dirs=($(find . -type f -path '*/bin/activate' -exec dirname {} \;))

  # If no directories found, print a message
  if [[ ${#found_dirs[@]} -eq 0 ]]; then
    echo "Could not find bin/activate"
    return 1
  fi

  # If exactly one directory is found, source it directly
  #if [[ ${#found_dirs[@]} -eq 1 ]]; then
  #  echo "Activating: ${found_dirs[1]}/activate"
  #  source "${found_dirs[1]}/activate"
  #  return 0
  #fi

  # If multiple directories are found, let the user choose via fzf
  chosen_dir=$(printf "%s\n" "${found_dirs[@]}" | fzf --prompt="Select an activate directory: " -1)

  # If a directory was selected, source the corresponding "activate"
  if [[ -n $chosen_dir ]]; then
    echo "Activating: $chosen_dir/activate"
    source "$chosen_dir/activate"
  else
    echo "No directory selected."
    return 1
  fi
}



